﻿using System;

namespace Dog
{
    enum Gender
    {
        Male,
        Female
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Get Name
            Console.WriteLine("What is the name of the dog?");
            string name = Console.ReadLine();
            //Get Owner
            Console.WriteLine("Who is the dog's owner?");
            string owner = Console.ReadLine();
            //Get Age
            Console.WriteLine("What is the dog's age?");
            int age = Console.ReadLine();
        }
        public class Dog
        {
            public string Name;
            public string Owner;
            public int Age;
            public Gender gender;


            public Bark()
            {
                int count = 0;
                for count < 11;
                    Console.WriteLine("Woof!")
                    count ++ 1
                return "Woof!"
            }
            public GetTag()
            {
                return "If lost, call", Owner, "their name is", Name, "and they are", age, "years old"
            }
        }
    }
}